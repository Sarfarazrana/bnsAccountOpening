package com.bns.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bns.exception.ResourceNotFoundException;
import com.bns.model.AccOpeningReg;
import com.bns.service.AccOpeningEmailInfoService;
import com.bns.service.AccOpeningRegService;
import com.bns.utility.EncryptionDecryptionUtility;

@RestController
@CrossOrigin
public class AccOpeningController {

	@Autowired
	private AccOpeningRegService accOpeningRegService;

	@Autowired
	private AccOpeningEmailInfoService accOpeningEmailInfoService;

	@PostMapping("/accOpeningForm")
	public String accOpeningForm(@RequestBody AccOpeningReg accOpeningReg) throws Exception {
		System.out.println("inisde accOpeningForm");

		return accOpeningRegService.createAccount(accOpeningReg);
	}

	@GetMapping("/validateAccountMail")
	public String validateAccountMail(@RequestParam(name = "key") String key) {
		String accRegId;
		System.out.println("Key is :" + key);
		System.out.println("Id is :" + EncryptionDecryptionUtility.decrypt(String.valueOf(key), "MAKWANAMEHUL"));
		accRegId = EncryptionDecryptionUtility.decrypt(String.valueOf(key), "MAKWANAMEHUL");

		System.out.println("accRegIdis :" + accRegId);
		return accOpeningEmailInfoService.verifyAccEmailAddress(accRegId);
	}

}
