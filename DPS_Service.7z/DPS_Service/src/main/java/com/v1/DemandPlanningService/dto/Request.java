package com.v1.DemandPlanningService.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.v1.DemandPlanningService.bean.UserInfo;

public class Request extends UserInfo implements Serializable  {

	/**
	 * @author makwameh
	 */
	private static final long serialVersionUID = -7983044545945617431L;
	
	@NotNull
	private String token;
	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
}
