package com.bns.utility;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.stereotype.Service;

@Service
public class VerificationMailSendingCls {

	static public boolean sendMailFunc(String reciverMail, int uniqueId) {
		boolean returnVal = false;
		String mailKey = "";
		final String mailValidationURL = "http://localhost:8080/validateAccountMail?key=";
		String preparedMailValidationURL = "";
		System.out.println("reciverMail is :" + reciverMail);

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		try {
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("mehulmakwana339@gmail.com", "Prutha@2210");
				}
			});

			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress("mehulmakwana339@gmail.com", false));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(reciverMail));
			msg.setSubject("Account Creation with BNS Distribution");
			msg.setContent("Please verify your email id via click link Below Unique id is :" + uniqueId, "text/html");
			msg.setSentDate(new Date());

			MimeBodyPart messageBodyPart = new MimeBodyPart();
			mailKey = EncryptionDecryptionUtility.encrypt(String.valueOf(uniqueId), "MAKWANAMEHUL");
			preparedMailValidationURL = mailValidationURL + mailKey;

			String sendMessage = "<a \"target=\"_blank\" href=" + preparedMailValidationURL
					+ ">Validate Email Address</a>";
			messageBodyPart.setContent(sendMessage, "text/html");

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			MimeBodyPart attachPart = new MimeBodyPart();

			/*
			 * attachPart.attachFile("images/DEMO.PNG"); multipart.addBodyPart(attachPart);
			 */
			msg.setContent(multipart);
			Transport.send(msg);
			returnVal = true;
			System.out.println("Email sent");

		} catch (Exception e) {
			returnVal = false;
			e.printStackTrace();
			System.out.println("Exception while sending mail");
		}

		return returnVal;
	}

}
