package com.v1.DemandPlanningService.dao;


public interface ApplicationConfigDao {
	
	
	
	
}
